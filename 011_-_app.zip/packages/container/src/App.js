import React from 'react';

export default () => {
  return <h1>Hi there!</h1>;
};
