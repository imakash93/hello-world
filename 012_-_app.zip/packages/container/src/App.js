import React from 'react';
import { mount } from 'marketing/MarketingApp';

console.log(mount);

export default () => {
  return <h1>Hi there!</h1>;
};
